window.onload = function(){
    const viewer = new GcPdfViewer("#viewer", {
        workerSrc: "node_modules/@grapecity/gcpdfviewer/gcpdfviewer.worker.js",
        supportApi: {
            apiUrl: "http://localhost:5004/api/pdf-viewer",
            token: "support-api-demo-net-core-token-2021",
            webSocketUrl: false
        }
    });
    viewer.addDefaultPanels();
    viewer.addAnnotationEditorPanel();
    viewer.addFormEditorPanel();
    viewer.open("assets/pdf/realestate-lease.pdf");
}
